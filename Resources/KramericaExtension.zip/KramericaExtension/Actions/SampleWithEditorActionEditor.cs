﻿using Inedo.BuildMaster.Extensibility.Actions;
using Inedo.BuildMaster.Web.Controls.Extensions;
using Inedo.Web.Controls;

namespace KramericaExtension.Actions
{
    public sealed class SampleWithEditorActionEditor : ActionEditorBase
    {
        // this is just a normal control with two required methods (Bind and Create)
        // CustomAttributeAction does support .ascx controls, though we find that having
        // pure C# controls are a bit easier to code/debug/maintain

        private ValidatingTextBox txtInformationText;
        private ValidatingTextBox txtWarningText;
        
        protected override void CreateChildControls()
        {
            this.txtInformationText = new ValidatingTextBox { Required = false };
            this.txtWarningText = new ValidatingTextBox { Required = false };

            // v4.2 Cleaner Form Fields
            this.Controls.Add(
                new SlimFormField("Information text:", this.txtInformationText),
                new SlimFormField("Warning text:", this.txtWarningText)
            );

            // PRE v4.2 FormFieldGroups
            /*
            this.Controls.Add(
                // FormFieldGroup controls are what we use to have the two-column appearance
                // not necessary, but it keeps a consistent UI
                new FormFieldGroup(
                    "Texts to Log",
                    "When left empty, no text will be logged.",
                    false,
                    new StandardFormField("Information Text:", this.txtInformationText),
                    new StandardFormField("Warning Text:", this.txtWarningText)
                )
            );
            */
        }

        public override void BindToForm(ActionBase extension)
        {
            // unless this editor is used by multiple actions, we can
            // be assured that the extension being passed in is the class
            // we linked with CustomEditorAttribute
            var action = (SampleWithEditorAction)extension;
            this.txtWarningText.Text = action.WarningText;
            this.txtInformationText.Text = action.InformationText;
        }

        public override ActionBase CreateFromForm()
        {
            return new SampleWithEditorAction
            {
                InformationText = this.txtInformationText.Text,
                WarningText = this.txtWarningText.Text
            };
        }
    }
}
