﻿using System.Linq;
using Inedo.BuildMaster;
using Inedo.BuildMaster.Extensibility.Actions;

namespace KramericaExtension.Actions
{
 
    [ActionProperties(
        "Sample Action",
        "An action that demonstrates basic ActionBase usage by logging the specified text. " 
        + "ActionBase actions are not designed to interact with agents.")]
    [Tag("sample")]
    public class SampleAction : ActionBase 
        // this action is not sealed because it's inherited by SampleWithEditorAction; if this
        // were a real extension, we'd likely make an abstract base class with an internal 
        // constructor. Extensions should generally not reference/link other extension assemblies,
        // especially for inheritance purposes, and sealing enforces this practice
    {
        /// <summary>
        /// Gets or sets the warning text.
        /// </summary>
        /// <remarks>
        /// If null or empty, no warning text will be logged.
        /// </remarks>
        [Persistent]
        public string WarningText { get; set; }

        /// <summary>
        /// Gets or sets the information text.
        /// </summary>
        /// <remarks>
        /// If null or empty, no information text will be logged.
        /// </remarks>
        [Persistent]
        public string InformationText { get; set; }

        /// <summary>
        /// This method is called to execute the Action.
        /// </summary>
        protected override void Execute()
        {
            // note that using LogError will result in a failed action!
            
            this.LogDebug("Logging text...");
            if (!string.IsNullOrEmpty(this.WarningText)) this.LogWarning(this.WarningText);
            if (!string.IsNullOrEmpty(this.InformationText)) this.LogInformation(this.InformationText);
            this.LogDebug("Finished logging!");
           
        }

        /// <summary>
        /// Returns a description of the current configuration of the action.
        /// </summary>
        /// <remarks>Note this method is new in v4.2 and it makes it easier to display action descriptions on the
        /// deployment plan overview page, and allows highlighting to be specified.</remarks>
        public override ActionDescription GetActionDescription()
        {
            string logTextType; string logText = null;
            if (!string.IsNullOrEmpty(this.WarningText))
            {
                logTextType = "Warning";
                logText = this.WarningText;
            }
            else if (!string.IsNullOrEmpty(this.InformationText))
            {
                logTextType = "Information";
                logText = this.InformationText;
            }
            else
            {
                logTextType = "Nothing";
            }

            logText = logText ?? "";
            logText = new string(logText.Take(50).ToArray());

            return new ActionDescription(
                new ShortActionDescription("Log ", new Hilite(logTextType)),
                new LongActionDescription(logText)
            );
        }
    }
}
