﻿using System.Reflection;
using System.Runtime.InteropServices;
using Inedo.BuildMaster.Extensibility;

[assembly: AssemblyTitle("KramericaExtension")]
[assembly: AssemblyDescription("Custom BuildMaster Extension for Kramerica.")]
[assembly: AssemblyCompany("Kramerica")]
[assembly: AssemblyCopyright("Copyright ©  2012")]

[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

[assembly: BuildMasterAssembly]
[assembly: RequiredBuildMasterVersion("3.5.0")]
