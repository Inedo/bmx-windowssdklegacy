﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Inedo.BuildMaster;
using Inedo.BuildMaster.Events;
using Inedo.BuildMaster.Extensibility.EventListeners;

namespace KramericaExtension.EventListeners
{
    [EventListenerProperties(
        "Sample Event Listener", 
        "Logs every SystemConfigurationChangedEvent event to a text file.")]
    public sealed class SampleEventListener : EventListenerBase<SystemConfigurationChangedEvent>
        // there are some other nice classes, like EmailEventListenerBase
        // if you want to listen to multiple events, then don't use the generic
    {
        [Persistent]
        public string TextFilePath { get; set; }

        public override void EventOccurred(SystemConfigurationChangedEvent eventDetails)
        {
            File.AppendAllText(
                this.TextFilePath, 
                string.Format("{0} - Event triggered; key changed was {1}.",
                    DateTime.Now,eventDetails.KeyName));

        }
    }
}
